_____________________________________________________________

                UN ESEGUIBILE DI AUGURI

Una cartolina di Natale personalizzabile per gli utenti Linux

@2019 Scuola_Sisini
https://pumar.it
francescomichelesisini@gmail.com
_____________________________________________________________

SE STAI LEGGENDO E' PERCHE' QUALCUNO HA PENSATO A TE E TI HA
INVIATO QUESTO ESEGUIBILE DI AUGURI

PER ESEGUIRLO SEGUI LE ISTRUZIONI QUI SOTTO, PER INVIARNE UNO
A TUA VOLTA, VAI SUL SITO https://pumar.it E SCARICA IL KIT

ISTRUZIONI:
        - Apri un terminale e vai alla directry auguri 
        - Lancia gli auguri: ./auguri_2019

Se non senti la musica, puoi installare la libreria openal





